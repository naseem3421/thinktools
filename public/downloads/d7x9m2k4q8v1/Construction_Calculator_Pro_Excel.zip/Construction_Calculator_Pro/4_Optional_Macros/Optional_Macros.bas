Attribute VB_Name = "ConstructionCalcMacros"
' OPTIONAL. Excel .xlsx files cannot hold macros, so this is NOT inside the workbook.
' To use: save a copy of the workbook as .xlsm, press Alt+F11, Insert > Module, paste this, save.
' Buyers on Mac or on Excel for the web may not be able to run macros. Test before you sell a macro version.
' Tab names must match exactly. Sheets are protected without a password, so Unprotect/Protect work as shown.

Sub ExportClientReportPDF()
    Dim p As String
    p = ThisWorkbook.Path & Application.PathSeparator & "Client_Report_" & Format(Date, "yyyy-mm-dd") & ".pdf"
    ThisWorkbook.Worksheets("Client Report").ExportAsFixedFormat Type:=xlTypePDF, Filename:=p, OpenAfterPublish:=True
End Sub

Sub ExportQuotationPDF()
    Dim p As String
    p = ThisWorkbook.Path & Application.PathSeparator & "Quotation_" & Format(Date, "yyyy-mm-dd") & ".pdf"
    ThisWorkbook.Worksheets("Quotation").ExportAsFixedFormat Type:=xlTypePDF, Filename:=p, OpenAfterPublish:=True
End Sub
